(function(g){
function A(x,y){var l=(x&65535)+(y&65535),m=(x>>>16)+(y>>>16)+(l>>>16);return(m<<16)|(l&65535)}
function R(n,c){return(n<<c)|(n>>>(32-c))}
function C(q,a,b,x,s,t){return A(R(A(A(a,q),A(x,t)),s),b)}
function F(a,b,c,d,x,s,t){return C((b&c)|((~b)&d),a,b,x,s,t)}
function G(a,b,c,d,x,s,t){return C((b&d)|(c&(~d)),a,b,x,s,t)}
function H(a,b,c,d,x,s,t){return C(b^c^d,a,b,x,s,t)}
function I(a,b,c,d,x,s,t){return C(c^(b|(~d)),a,b,x,s,t)}
function words(str){
  /* IMPORTANT FOR MIKROTIK HTTP-CHAP:
     chap-id and chap-challenge are binary byte strings represented by RouterOS
     escape sequences. Do NOT UTF-8 encode them. Hash the low 8 bits exactly. */
  var n=str.length,out=[];
  for(var i=0;i<n;i++){
    out[i>>2]=(out[i>>2]||0)|((str.charCodeAt(i)&255)<<((i%4)*8));
  }
  out[n>>2]=(out[n>>2]||0)|(0x80<<((n%4)*8));
  out[(((n+8)>>6)<<4)+14]=n*8;
  return out;
}
function hex(n){var s="",h="0123456789abcdef";for(var j=0;j<4;j++){var v=(n>>>(j*8))&255;s+=h[(v>>>4)&15]+h[v&15]}return s}
g.hexMD5=function(str){
  var x=words(str),a=1732584193,b=-271733879,c=-1732584194,d=271733878;
  for(var i=0;i<x.length;i+=16){
    var oa=a,ob=b,oc=c,od=d;
    a=F(a,b,c,d,x[i+0]||0,7,-680876936);d=F(d,a,b,c,x[i+1]||0,12,-389564586);c=F(c,d,a,b,x[i+2]||0,17,606105819);b=F(b,c,d,a,x[i+3]||0,22,-1044525330);
    a=F(a,b,c,d,x[i+4]||0,7,-176418897);d=F(d,a,b,c,x[i+5]||0,12,1200080426);c=F(c,d,a,b,x[i+6]||0,17,-1473231341);b=F(b,c,d,a,x[i+7]||0,22,-45705983);
    a=F(a,b,c,d,x[i+8]||0,7,1770035416);d=F(d,a,b,c,x[i+9]||0,12,-1958414417);c=F(c,d,a,b,x[i+10]||0,17,-42063);b=F(b,c,d,a,x[i+11]||0,22,-1990404162);
    a=F(a,b,c,d,x[i+12]||0,7,1804603682);d=F(d,a,b,c,x[i+13]||0,12,-40341101);c=F(c,d,a,b,x[i+14]||0,17,-1502002290);b=F(b,c,d,a,x[i+15]||0,22,1236535329);
    a=G(a,b,c,d,x[i+1]||0,5,-165796510);d=G(d,a,b,c,x[i+6]||0,9,-1069501632);c=G(c,d,a,b,x[i+11]||0,14,643717713);b=G(b,c,d,a,x[i+0]||0,20,-373897302);
    a=G(a,b,c,d,x[i+5]||0,5,-701558691);d=G(d,a,b,c,x[i+10]||0,9,38016083);c=G(c,d,a,b,x[i+15]||0,14,-660478335);b=G(b,c,d,a,x[i+4]||0,20,-405537848);
    a=G(a,b,c,d,x[i+9]||0,5,568446438);d=G(d,a,b,c,x[i+14]||0,9,-1019803690);c=G(c,d,a,b,x[i+3]||0,14,-187363961);b=G(b,c,d,a,x[i+8]||0,20,1163531501);
    a=G(a,b,c,d,x[i+13]||0,5,-1444681467);d=G(d,a,b,c,x[i+2]||0,9,-51403784);c=G(c,d,a,b,x[i+7]||0,14,1735328473);b=G(b,c,d,a,x[i+12]||0,20,-1926607734);
    a=H(a,b,c,d,x[i+5]||0,4,-378558);d=H(d,a,b,c,x[i+8]||0,11,-2022574463);c=H(c,d,a,b,x[i+11]||0,16,1839030562);b=H(b,c,d,a,x[i+14]||0,23,-35309556);
    a=H(a,b,c,d,x[i+1]||0,4,-1530992060);d=H(d,a,b,c,x[i+4]||0,11,1272893353);c=H(c,d,a,b,x[i+7]||0,16,-155497632);b=H(b,c,d,a,x[i+10]||0,23,-1094730640);
    a=H(a,b,c,d,x[i+13]||0,4,681279174);d=H(d,a,b,c,x[i+0]||0,11,-358537222);c=H(c,d,a,b,x[i+3]||0,16,-722521979);b=H(b,c,d,a,x[i+6]||0,23,76029189);
    a=H(a,b,c,d,x[i+9]||0,4,-640364487);d=H(d,a,b,c,x[i+12]||0,11,-421815835);c=H(c,d,a,b,x[i+15]||0,16,530742520);b=H(b,c,d,a,x[i+2]||0,23,-995338651);
    a=I(a,b,c,d,x[i+0]||0,6,-198630844);d=I(d,a,b,c,x[i+7]||0,10,1126891415);c=I(c,d,a,b,x[i+14]||0,15,-1416354905);b=I(b,c,d,a,x[i+5]||0,21,-57434055);
    a=I(a,b,c,d,x[i+12]||0,6,1700485571);d=I(d,a,b,c,x[i+3]||0,10,-1894986606);c=I(c,d,a,b,x[i+10]||0,15,-1051523);b=I(b,c,d,a,x[i+1]||0,21,-2054922799);
    a=I(a,b,c,d,x[i+8]||0,6,1873313359);d=I(d,a,b,c,x[i+15]||0,10,-30611744);c=I(c,d,a,b,x[i+6]||0,15,-1560198380);b=I(b,c,d,a,x[i+13]||0,21,1309151649);
    a=I(a,b,c,d,x[i+4]||0,6,-145523070);d=I(d,a,b,c,x[i+11]||0,10,-1120210379);c=I(c,d,a,b,x[i+2]||0,15,718787259);b=I(b,c,d,a,x[i+9]||0,21,-343485551);
    a=A(a,oa);b=A(b,ob);c=A(c,oc);d=A(d,od);
  }
  return hex(a)+hex(b)+hex(c)+hex(d);
}
})(window);
