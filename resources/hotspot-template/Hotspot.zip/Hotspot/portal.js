
(function(){
  const LANGS = {
    en:{dir:"ltr",t:{
      voucher_login:"Voucher Login",voucher_desc:"Enter your 6-digit voucher code to access the internet",voucher_placeholder:"6-digit voucher code",login:"Login",
      device_info:"Device Information",your_ip:"Your IP",your_mac:"Your MAC",voucher:"Voucher",
      random_title:"Private / Random MAC detected",random_desc:"Your phone is using a private/random Wi‑Fi MAC. Genius vouchers are not locked to a MAC, so login will still work.",
      move_title:"Move Voucher to Another Device",move_desc:"This MikroTik-only setup does not permanently bind vouchers to a MAC. Login with the same voucher on the new device; the router releases the previous session automatically.",
      connected_title:"You're Connected!",connected:"Connected",connected_desc:"You are successfully connected to Genius Wi‑Fi.",
      session_details:"Session Details",uptime:"Session Uptime",time_remaining:"Time Remaining",downloaded:"Downloaded",uploaded:"Uploaded",
      refresh:"Refresh Status",release:"MAC Reset / Release Voucher",release_desc:"Log out this device and erase the Hotspot browser cookie so the voucher is ready for another device.",
      logout:"Logout",logged_out:"Voucher Released",logged_out_desc:"This device has been logged out. You can now use the voucher on another device.",
      login_again:"Login Again",help_title:"Need Help?",help_desc:"Contact Genius Information Technology W.L.L for assistance."
    }},
    bn:{dir:"ltr",t:{
      voucher_login:"ভাউচার লগইন",voucher_desc:"ইন্টারনেট ব্যবহারের জন্য ৬ সংখ্যার ভাউচার কোড লিখুন",voucher_placeholder:"৬ সংখ্যার ভাউচার কোড",login:"লগইন",
      device_info:"ডিভাইস তথ্য",your_ip:"আপনার IP",your_mac:"আপনার MAC",voucher:"ভাউচার",
      random_title:"Private / Random MAC শনাক্ত হয়েছে",random_desc:"আপনার ফোন Private/Random Wi‑Fi MAC ব্যবহার করছে। Genius voucher MAC-এ স্থায়ীভাবে lock করা নেই, তাই login কাজ করবে।",
      move_title:"অন্য ডিভাইসে Voucher ব্যবহার",move_desc:"এই MikroTik-only setup-এ voucher স্থায়ীভাবে MAC-এ bind হয় না। নতুন ডিভাইসে একই voucher দিয়ে login করলে router আগের session release করবে।",
      connected_title:"আপনি সংযুক্ত!",connected:"সংযুক্ত",connected_desc:"আপনি সফলভাবে Genius Wi‑Fi-তে সংযুক্ত আছেন।",
      session_details:"সেশন বিস্তারিত",uptime:"সেশন সময়",time_remaining:"অবশিষ্ট সময়",downloaded:"ডাউনলোড",uploaded:"আপলোড",
      refresh:"স্ট্যাটাস রিফ্রেশ",release:"MAC Reset / Voucher Release",release_desc:"এই ডিভাইস logout করে Hotspot browser cookie মুছে voucher অন্য ডিভাইসের জন্য ছেড়ে দিন।",
      logout:"লগআউট",logged_out:"Voucher Release হয়েছে",logged_out_desc:"এই ডিভাইস logout হয়েছে। এখন voucher অন্য ডিভাইসে ব্যবহার করা যাবে।",
      login_again:"আবার লগইন",help_title:"সাহায্য দরকার?",help_desc:"সহায়তার জন্য Genius Information Technology W.L.L-এর সাথে যোগাযোগ করুন।"
    }},
    hi:{dir:"ltr",t:{
      voucher_login:"वाउचर लॉगिन",voucher_desc:"इंटरनेट के लिए 6 अंकों का वाउचर कोड दर्ज करें",voucher_placeholder:"6 अंकों का वाउचर",login:"लॉगिन",
      device_info:"डिवाइस जानकारी",your_ip:"आपका IP",your_mac:"आपका MAC",voucher:"वाउचर",
      random_title:"Private / Random MAC मिला",random_desc:"फोन Private/Random Wi‑Fi MAC इस्तेमाल कर रहा है। Genius voucher स्थायी रूप से MAC से लॉक नहीं है।",
      move_title:"वाउचर दूसरे डिवाइस पर चलाएँ",move_desc:"यह MikroTik-only सेटअप voucher को MAC से स्थायी रूप से bind नहीं करता। नए डिवाइस पर वही voucher लॉगिन करें; पुराना session release हो जाएगा।",
      connected_title:"आप कनेक्ट हैं!",connected:"कनेक्टेड",connected_desc:"आप Genius Wi‑Fi से सफलतापूर्वक जुड़े हैं।",
      session_details:"सेशन विवरण",uptime:"सेशन समय",time_remaining:"बाकी समय",downloaded:"डाउनलोड",uploaded:"अपलोड",
      refresh:"स्टेटस रिफ्रेश",release:"MAC Reset / Release Voucher",release_desc:"इस डिवाइस को logout करके Hotspot browser cookie मिटाएँ और voucher दूसरे डिवाइस के लिए छोड़ें।",
      logout:"लॉगआउट",logged_out:"Voucher Release हो गया",logged_out_desc:"यह डिवाइस logout हो गया है। अब voucher दूसरे डिवाइस पर इस्तेमाल किया जा सकता है।",
      login_again:"फिर से लॉगिन",help_title:"मदद चाहिए?",help_desc:"सहायता के लिए Genius Information Technology W.L.L से संपर्क करें।"
    }},
    ne:{dir:"ltr",t:{
      voucher_login:"भाउचर लगइन",voucher_desc:"इन्टरनेटका लागि ६-अङ्कको भाउचर कोड प्रविष्ट गर्नुहोस्",voucher_placeholder:"६-अङ्कको भाउचर",login:"लगइन",
      device_info:"डिभाइस जानकारी",your_ip:"तपाईंको IP",your_mac:"तपाईंको MAC",voucher:"भाउचर",
      random_title:"Private / Random MAC देखियो",random_desc:"फोनले Private/Random Wi‑Fi MAC प्रयोग गरिरहेको छ। Genius voucher स्थायी रूपमा MAC मा lock हुँदैन।",
      move_title:"अर्को डिभाइसमा Voucher",move_desc:"यो MikroTik-only सेटअपमा voucher स्थायी MAC binding हुँदैन। नयाँ डिभाइसमा उही voucher लगइन गर्दा पुरानो session release हुन्छ।",
      connected_title:"तपाईं जडान हुनुभयो!",connected:"जडान भएको",connected_desc:"तपाईं Genius Wi‑Fi मा सफलतापूर्वक जडान हुनुहुन्छ।",
      session_details:"सेसन विवरण",uptime:"सेसन समय",time_remaining:"बाँकी समय",downloaded:"डाउनलोड",uploaded:"अपलोड",
      refresh:"स्टेटस रिफ्रेस",release:"MAC Reset / Release Voucher",release_desc:"यो डिभाइस logout गरी Hotspot browser cookie हटाउनुहोस् र voucher अर्को डिभाइसका लागि release गर्नुहोस्।",
      logout:"लगआउट",logged_out:"Voucher Release भयो",logged_out_desc:"यो डिभाइस logout भयो। अब voucher अर्को डिभाइसमा प्रयोग गर्न सकिन्छ।",
      login_again:"फेरि लगइन",help_title:"मद्दत चाहिन्छ?",help_desc:"सहायताका लागि Genius Information Technology W.L.L लाई सम्पर्क गर्नुहोस्।"
    }},
    ur:{dir:"rtl",t:{
      voucher_login:"واؤچر لاگ اِن",voucher_desc:"انٹرنیٹ کے لیے 6 ہندسوں کا واؤچر کوڈ درج کریں",voucher_placeholder:"6 ہندسوں کا واؤچر",login:"لاگ اِن",
      device_info:"ڈیوائس معلومات",your_ip:"آپ کا IP",your_mac:"آپ کا MAC",voucher:"واؤچر",
      random_title:"Private / Random MAC ملا",random_desc:"فون Private/Random Wi‑Fi MAC استعمال کر رہا ہے۔ Genius voucher مستقل طور پر MAC سے lock نہیں ہے۔",
      move_title:"واؤچر دوسرے ڈیوائس پر استعمال کریں",move_desc:"یہ MikroTik-only سیٹ اپ voucher کو مستقل MAC سے bind نہیں کرتا۔ نئے ڈیوائس پر وہی voucher login کریں؛ پرانا session release ہو جائے گا۔",
      connected_title:"آپ کنیکٹ ہیں!",connected:"کنیکٹڈ",connected_desc:"آپ کامیابی سے Genius Wi‑Fi سے منسلک ہیں۔",
      session_details:"سیشن تفصیل",uptime:"سیشن وقت",time_remaining:"باقی وقت",downloaded:"ڈاؤن لوڈ",uploaded:"اپ لوڈ",
      refresh:"اسٹیٹس ریفریش",release:"MAC Reset / Release Voucher",release_desc:"اس ڈیوائس کو logout کریں، Hotspot browser cookie مٹائیں اور voucher دوسرے ڈیوائس کے لیے release کریں۔",
      logout:"لاگ آؤٹ",logged_out:"Voucher Release ہو گیا",logged_out_desc:"یہ ڈیوائس logout ہو گیا ہے۔ اب voucher دوسرے ڈیوائس پر استعمال ہو سکتا ہے۔",
      login_again:"دوبارہ لاگ اِن",help_title:"مدد چاہیے؟",help_desc:"مدد کے لیے Genius Information Technology W.L.L سے رابطہ کریں۔"
    }},
    ta:{dir:"ltr",t:{
      voucher_login:"வவுச்சர் உள்நுழைவு",voucher_desc:"இணையத்திற்கு 6 இலக்க வவுச்சர் குறியீட்டை உள்ளிடவும்",voucher_placeholder:"6 இலக்க வவுச்சர்",login:"உள்நுழை",
      device_info:"சாதன தகவல்",your_ip:"உங்கள் IP",your_mac:"உங்கள் MAC",voucher:"வவுச்சர்",
      random_title:"Private / Random MAC கண்டறியப்பட்டது",random_desc:"உங்கள் தொலைபேசி Private/Random Wi‑Fi MAC பயன்படுத்துகிறது. Genius voucher நிரந்தரமாக MAC-க்கு lock செய்யப்படவில்லை.",
      move_title:"வேறு சாதனத்தில் Voucher பயன்படுத்த",move_desc:"இந்த MikroTik-only அமைப்பு voucher-ஐ நிரந்தர MAC binding செய்யாது. புதிய சாதனத்தில் அதே voucher-ஐ login செய்தால் பழைய session release ஆகும்.",
      connected_title:"இணைக்கப்பட்டுள்ளீர்கள்!",connected:"இணைக்கப்பட்டது",connected_desc:"Genius Wi‑Fi உடன் வெற்றிகரமாக இணைக்கப்பட்டுள்ளீர்கள்.",
      session_details:"அமர்வு விவரங்கள்",uptime:"அமர்வு நேரம்",time_remaining:"மீதமுள்ள நேரம்",downloaded:"பதிவிறக்கம்",uploaded:"பதிவேற்றம்",
      refresh:"நிலையை புதுப்பிக்க",release:"MAC Reset / Release Voucher",release_desc:"இந்த சாதனத்தை logout செய்து Hotspot browser cookie-ஐ அழித்து voucher-ஐ மற்றொரு சாதனத்திற்கு release செய்யவும்.",
      logout:"வெளியேறு",logged_out:"Voucher Release ஆனது",logged_out_desc:"இந்த சாதனம் logout ஆனது. இப்போது voucher-ஐ வேறு சாதனத்தில் பயன்படுத்தலாம்.",
      login_again:"மீண்டும் உள்நுழை",help_title:"உதவி வேண்டுமா?",help_desc:"உதவிக்கு Genius Information Technology W.L.L-ஐ தொடர்பு கொள்ளவும்."
    }},
    ar:{dir:"rtl",t:{
      voucher_login:"تسجيل الدخول بالقسيمة",voucher_desc:"أدخل رمز القسيمة المكون من 6 أرقام للوصول إلى الإنترنت",voucher_placeholder:"قسيمة من 6 أرقام",login:"تسجيل الدخول",
      device_info:"معلومات الجهاز",your_ip:"عنوان IP",your_mac:"عنوان MAC",voucher:"القسيمة",
      random_title:"تم اكتشاف Private / Random MAC",random_desc:"الهاتف يستخدم Private/Random Wi‑Fi MAC. قسيمة Genius ليست مقفلة بشكل دائم على MAC.",
      move_title:"استخدام القسيمة على جهاز آخر",move_desc:"إعداد MikroTik-only لا يربط القسيمة بشكل دائم بعنوان MAC. سجّل الدخول بنفس القسيمة على الجهاز الجديد وسيتم إنهاء الجلسة السابقة.",
      connected_title:"أنت متصل!",connected:"متصل",connected_desc:"تم الاتصال بنجاح بشبكة Genius Wi‑Fi.",
      session_details:"تفاصيل الجلسة",uptime:"مدة الجلسة",time_remaining:"الوقت المتبقي",downloaded:"التنزيل",uploaded:"الرفع",
      refresh:"تحديث الحالة",release:"MAC Reset / Release Voucher",release_desc:"سجّل خروج هذا الجهاز وامسح Hotspot browser cookie لتحرير القسيمة لجهاز آخر.",
      logout:"تسجيل الخروج",logged_out:"تم تحرير القسيمة",logged_out_desc:"تم تسجيل خروج هذا الجهاز. يمكن الآن استخدام القسيمة على جهاز آخر.",
      login_again:"تسجيل الدخول مرة أخرى",help_title:"هل تحتاج مساعدة؟",help_desc:"تواصل مع Genius Information Technology W.L.L للحصول على المساعدة."
    }}
  };

  const $ = s => document.querySelector(s);
  const $$ = s => Array.from(document.querySelectorAll(s));
  let lang = localStorage.getItem("genius_lang") || "en";
  if(!LANGS[lang]) lang = "en";
  function tr(k){return LANGS[lang].t[k] || LANGS.en.t[k] || k}
  function applyLang(){
    document.documentElement.lang=lang;
    document.documentElement.dir=LANGS[lang].dir;
    $$("[data-i18n]").forEach(el=>{
      const k=el.dataset.i18n;
      if(el.tagName==="INPUT") el.placeholder=tr(k); else el.textContent=tr(k);
    });
    $$(".langbar button[data-lang]").forEach(b=>b.classList.toggle("active",b.dataset.lang===lang));
  }
  $$(".langbar button[data-lang]").forEach(b=>b.addEventListener("click",()=>{
    lang=b.dataset.lang; localStorage.setItem("genius_lang",lang); applyLang();
  }));

  function cleanMac(mac){return (mac||"").replace(/[^0-9a-f]/gi,"")}
  function locallyAdmin(mac){
    const c=cleanMac(mac); if(c.length!==12)return false;
    const first=parseInt(c.slice(0,2),16);
    return Number.isFinite(first)&&((first&0x02)===0x02);
  }
  const warn=$("#randomMacWarning");
  if(warn && locallyAdmin(document.body.dataset.mac||"")) warn.classList.remove("hidden");

  applyLang();
})();
